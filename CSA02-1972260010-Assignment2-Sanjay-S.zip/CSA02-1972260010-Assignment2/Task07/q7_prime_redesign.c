#include <stdio.h>
int prime_odd(unsigned long n, unsigned long *checks) {
    *checks = 0;
    if (n < 2) return 0;
    if (n == 2) return 1;
    (*checks)++;
    if (n % 2 == 0) return 0;
    for (unsigned long i = 3; i <= n / i; i += 2) {
        (*checks)++;
        if (n % i == 0) return 0;
    }
    return 1;
}
int main(void) {
    unsigned long values[] = {97, 100, 7919, 1000003};
    for (int k = 0; k < 4; k++) {
        unsigned long checks;
        int result = prime_odd(values[k], &checks);
        printf("%8lu %-9s modulo checks = %lu\n",
               values[k], result ? "prime" : "not prime", checks);
    }
    return 0;
}