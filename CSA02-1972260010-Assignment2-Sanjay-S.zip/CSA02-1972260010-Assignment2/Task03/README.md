# Task03 – C Programming Assignment 2

**Source file:** `q3_bitwise_register.c`

## Compile
```bash
gcc -std=c11 -Wall -Wextra -pedantic q3_bitwise_register.c -o program
```

## Run
```bash
./program
```

## Files
- `q3_bitwise_register.c` – C source code
- `output.txt` – sample run output
- `compile_log.txt` – GCC compilation result

**Note:** Capture your own terminal screenshot after compiling and running the program on your computer before submission.
