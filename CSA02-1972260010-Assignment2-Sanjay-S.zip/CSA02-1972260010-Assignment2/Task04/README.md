# Task04 – C Programming Assignment 2

**Source file:** `q4_grade.c`

## Compile
```bash
gcc -std=c11 -Wall -Wextra -pedantic q4_grade.c -o program
```

## Run
```bash
./program
```

## Files
- `q4_grade.c` – C source code
- `output.txt` – sample run output
- `compile_log.txt` – GCC compilation result

**Note:** Capture your own terminal screenshot after compiling and running the program on your computer before submission.
