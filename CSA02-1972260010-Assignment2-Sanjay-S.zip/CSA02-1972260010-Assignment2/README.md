# C Programming Assignment 2 – CO2

- Student Name: Sanjay S
- Register Number: 1972260010
- Compiler command: `gcc -std=c11 -Wall -Wextra -pedantic file.c -o program`

## Tasks
1. Task01 – Billing calculation, operator precedence and arithmetic.
2. Task02 – Short-circuit evaluation and verification call counts.
3. Task03 – Bitwise device-status register.
4. Task04 – Grade classification using switch and decision statements.
5. Task05 – Prime checking and loop operation counts.
6. Task06 – Loan repayment schedule and loop termination.
7. Task07 – Prime-checking redesign and validation.

## Folder contents
Each task folder contains its C source file, README, sample output and compile log.

## Before submission
- Check the assignment PDF and confirm that each program matches the exact question.
- Run every program on your own system.
- Add genuine terminal screenshots to each task folder.
- Check the installed compiler version using `gcc --version`.
- Create the GitHub repository named `CSA02-1972260010-Assignment2`.
- Commit each task progressively and add the working repository URL to your report.

**Important:** The sample outputs and compile logs are provided as reference files. Screenshots must be captured from your own execution.
