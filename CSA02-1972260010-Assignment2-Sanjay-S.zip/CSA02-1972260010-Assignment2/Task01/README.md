# Task01 – C Programming Assignment 2

**Source file:** `q1_billing.c`

## Compile
```bash
gcc -std=c11 -Wall -Wextra -pedantic q1_billing.c -o program
```

## Run
```bash
./program
```

## Files
- `q1_billing.c` – C source code
- `output.txt` – sample run output
- `compile_log.txt` – GCC compilation result

**Note:** Capture your own terminal screenshot after compiling and running the program on your computer before submission.
