#include <stdio.h>
int main(void) {
    double price, quantity, discount = 0.0, gst, total;
    int senior;
    printf("Enter unit price, quantity and senior-citizen status (1=yes, 0=no): ");
    if (scanf("%lf %lf %d", &price, &quantity, &senior) != 3 ||
        price < 0 || quantity <= 0 || (senior != 0 && senior != 1)) {
        printf("Invalid input\n");
        return 1;
    }
    double gross = price * quantity;
    if (senior) discount = gross * 0.15;
    double discounted = gross - discount;
    gst = discounted * 0.05;
    total = discounted + gst;
    if (total > 1000.0) total -= 50.0;
    printf("Gross amount = %.2f\nDiscount = %.2f\nGST = %.2f\nFinal amount = %.2f\n",
           gross, discount, gst, total);
    return 0;
}