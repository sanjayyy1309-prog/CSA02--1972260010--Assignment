#include <stdio.h>
int main(void) {
    double balance, rate, repayment, interest, paid;
    double total_interest = 0.0;
    int month = 0, limit = 360;
    printf("Enter loan amount, monthly rate (%%), repayment: ");
    if (scanf("%lf %lf %lf", &balance, &rate, &repayment) != 3 ||
        balance <= 0 || rate < 0 || repayment <= 0) {
        printf("Invalid input\n");
        return 1;
    }
    if (repayment <= balance * rate / 100.0) {
        printf("Repayment is not greater than monthly interest; loan will not decrease.\n");
        return 1;
    }
    printf("Month\tOpening\tInterest\tPayment\tClosing\n");
    while (balance > 0.005) {
        double opening = balance;
        if (month >= limit) {
            printf("Safety limit reached; loan is not fully repaid.\n");
            return 0;
        }
        month++;
        interest = balance * rate / 100.0;
        total_interest += interest;
        balance += interest;
        paid = (repayment < balance) ? repayment : balance;
        balance -= paid;
        if (balance < 0.005) balance = 0.0;
        printf("%d\t%.2f\t%.2f\t\t%.2f\t%.2f\n",
               month, opening, interest, paid, balance);
    }
    printf("Months = %d\nTotal interest = %.2f\n", month, total_interest);
    return 0;
}