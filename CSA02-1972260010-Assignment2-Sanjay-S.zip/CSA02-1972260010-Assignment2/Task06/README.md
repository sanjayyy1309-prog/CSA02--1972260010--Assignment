# Task06 – C Programming Assignment 2

**Source file:** `q6_loan.c`

## Compile
```bash
gcc -std=c11 -Wall -Wextra -pedantic q6_loan.c -o program
```

## Run
```bash
./program
```

## Files
- `q6_loan.c` – C source code
- `output.txt` – sample run output
- `compile_log.txt` – GCC compilation result

**Note:** Capture your own terminal screenshot after compiling and running the program on your computer before submission.
