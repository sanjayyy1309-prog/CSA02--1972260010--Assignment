# Task02 – C Programming Assignment 2

**Source file:** `q2_short_circuit.c`

## Compile
```bash
gcc -std=c11 -Wall -Wextra -pedantic q2_short_circuit.c -o program
```

## Run
```bash
./program
```

## Files
- `q2_short_circuit.c` – C source code
- `output.txt` – sample run output
- `compile_log.txt` – GCC compilation result

**Note:** Capture your own terminal screenshot after compiling and running the program on your computer before submission.
