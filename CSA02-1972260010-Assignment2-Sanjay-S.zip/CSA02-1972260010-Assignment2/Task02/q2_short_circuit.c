#include <stdio.h>
int calls = 0;
int verify_card(int has_card) {
    calls++;
    return has_card;
}
int main(void) {
    int senior[5] = {1, 0, 1, 0, 0};
    int eligible[5] = {1, 1, 0, 0, 1};
    int card[5] = {0, 1, 0, 1, 0};
    int i, concession;
    for (i = 0; i < 5; i++) {
        concession = (senior[i] && eligible[i]) || verify_card(card[i]);
        printf("Passenger %d: %s\n", i + 1,
               concession ? "CONCESSION" : "NO CONCESSION");
    }
    printf("Verification calls = %d\n", calls);
    return 0;
}