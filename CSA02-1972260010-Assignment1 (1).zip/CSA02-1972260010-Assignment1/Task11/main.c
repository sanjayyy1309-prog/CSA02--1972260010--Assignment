#include <stdio.h>
#include <limits.h>
#define FIXED_CHARGE_PAISE 5000L
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE2_PAISE 225L
#define RATE3_PAISE 450L

static long long bill_paise(unsigned int units) {
    long long p = FIXED_CHARGE_PAISE;
    if (units > SLAB2_UNITS) p += (long long)(units - SLAB2_UNITS) * RATE3_PAISE;
    if (units > SLAB1_UNITS) {
        unsigned int mid = (units < SLAB2_UNITS ? units : SLAB2_UNITS) - SLAB1_UNITS;
        p += (long long)mid * RATE2_PAISE;
    }
    return p;
}
int main(void) {
    unsigned int units[] = {0, 100, 150, 200, 350};
    for (unsigned int i = 0; i < sizeof units / sizeof units[0]; ++i) {
        long long p = bill_paise(units[i]);
        printf("%u units -> Rs %lld.%02lld\n", units[i], p / 100, p % 100);
    }
    printf("LLONG_MAX paise=%lld\n", LLONG_MAX);
    return 0;
}
