# Task11

Recommends long long for aggregate paise totals, integer paise for exact billing, centralised rates and validation. Runtime configuration is preferable when tariff changes frequently.
