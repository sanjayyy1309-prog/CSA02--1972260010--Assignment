# Task02

Completes the rollover function using unsigned 16-bit arithmetic, with no if-else.
