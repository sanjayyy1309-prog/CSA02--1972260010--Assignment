# Task05

Demonstrates a guarded header, separate translation units and compile-time DEBUG output. billing.c needs stdio.h when DEBUG is enabled; added in the tested version below if needed.
