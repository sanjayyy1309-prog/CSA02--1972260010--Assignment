#include <stdio.h>
#include "billing.h"
int main(void) {
    int units = 150;
    long p = compute_bill(units);
    printf("%d units -> Rs %ld.%02ld\n", units, p / 100, p % 100);
    return 0;
}
