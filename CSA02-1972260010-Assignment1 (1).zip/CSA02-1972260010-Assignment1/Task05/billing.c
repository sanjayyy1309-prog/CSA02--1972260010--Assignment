#include "billing.h"
#include <stdio.h>
#include <stdio.h>
long compute_bill(int units) {
    long paise = FIXED_CHARGE_PAISE;
    if (units > SLAB2_UNITS) paise += (long)(units - SLAB2_UNITS) * RATE3_PAISE;
    if (units > SLAB1_UNITS) {
        int capped = units < SLAB2_UNITS ? units : SLAB2_UNITS;
        paise += (long)(capped - SLAB1_UNITS) * RATE2_PAISE;
    }
#ifdef DEBUG
    fprintf(stderr, "[DEBUG] units=%d bill_paise=%ld\n", units, paise);
#endif
    return paise;
}
