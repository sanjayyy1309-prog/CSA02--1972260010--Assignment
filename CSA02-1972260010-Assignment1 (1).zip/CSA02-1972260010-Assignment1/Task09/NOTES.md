# Task09

Implements rollover-aware consumption, slab billing, input checks and a five-bill total. This simple unsigned difference assumes at most one register rollover between readings.
