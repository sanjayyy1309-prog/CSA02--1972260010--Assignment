#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

typedef unsigned short meter_t;
#define FIXED_CHARGE_PAISE 5000L
#define SLAB1_UNITS 100
#define SLAB2_UNITS 200
#define RATE2_PAISE 225L
#define RATE3_PAISE 450L

static unsigned int consumption(meter_t prev, meter_t curr) {
    return (unsigned short)(curr - prev);
}
static long compute_bill(unsigned int units) {
    long p = FIXED_CHARGE_PAISE;
    if (units > SLAB2_UNITS) p += (long)(units - SLAB2_UNITS) * RATE3_PAISE;
    if (units > SLAB1_UNITS) {
        unsigned int mid = (units < SLAB2_UNITS ? units : SLAB2_UNITS) - SLAB1_UNITS;
        p += (long)mid * RATE2_PAISE;
    }
    return p;
}
int main(void) {
    long long total = 0;
    for (int i = 0; i < 5; i++) {
        int prev, curr;
        printf("Bill %d - enter previous and current readings: ", i + 1);
        if (scanf("%d %d", &prev, &curr) != 2) {
            fprintf(stderr, "Invalid input.\n"); return 1;
        }
        if (prev < 0 || prev > USHRT_MAX || curr < 0 || curr > USHRT_MAX) {
            fprintf(stderr, "Readings out of range.\n"); return 1;
        }
        unsigned int units = consumption((meter_t)prev, (meter_t)curr);
        long bill = compute_bill(units);
        total += bill;
        printf("Units=%u Bill=Rs %ld.%02ld\n", units, bill / 100, bill % 100);
    }
    printf("Five-bill total: Rs %lld.%02lld\n", total / 100, total % 100);
    return 0;
}
