# Task03

Uses named macros for tariff values and stores monetary values as integer paise.
