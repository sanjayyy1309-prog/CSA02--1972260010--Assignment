#include <stdio.h>
#define RUPEES_TO_PAISE(r) ((long)(r) * 100L)
#define SQUARE(x) ((x) * (x))
#define MAX(a, b) ((a) > (b) ? (a) : (b))

static inline long rupees_to_paise(long rupees) { return rupees * 100L; }
static inline int square_int(int x) { return x * x; }
static inline int max_int(int a, int b) { return a > b ? a : b; }

int main(void) {
    int a = 3, b = 5;
    printf("Macro square: %d\n", SQUARE(a + 1));
    printf("Macro max: %d\n", MAX(a, b));
    printf("Rupees to paise: %ld\n", RUPEES_TO_PAISE(50));
    printf("Inline square: %d\n", square_int(a + 1));
    printf("Inline max: %d\n", max_int(a, b));
    printf("Inline rupees to paise: %ld\n", rupees_to_paise(50));
    return 0;
}
