# Task04

Shows fully parenthesised macros and safer static inline function alternatives. Avoid side-effecting arguments such as MAX(i++, j).
