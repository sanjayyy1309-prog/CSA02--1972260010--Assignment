# CSA02 C Programming Assignment 1
**Student:** Sanjay S  
**Register number:** 1972260010  
**Repository name required by brief:** `CSA02-1972260010-Assignment1`  
**Compiler:** GCC (record the exact output of `gcc --version` on your own system before submission)

## Build and run
From each task folder, compile a single-file task with:
```sh
gcc -std=c11 -Wall -Wextra -pedantic main.c -o program
./program
```
Task05 is a multi-file example:
```sh
gcc -std=c11 -Wall -Wextra -pedantic main.c billing.c -o program
./program
```
Task08 includes `build.sh` demonstrating `-E`, `-S`, `-c`, and linking. The `outputs/` directory contains logs from attempted compilation/execution in the generation environment; verify them on your own GCC system and add genuine terminal screenshots.

## Folder structure
- `Task01` ... `Task12`: task source code, notes, and test-case guidance.
- `outputs/`: compile/run logs created in the generation environment.
- `Assignment_Report.docx`: report covering Tasks 1–12.
- `REPORT.md`: editable Markdown version of the report.

## Task summary
1. Problem data, assumptions and invariants.
2. Data types and rollover arithmetic.
3. Centralised tariff constants and slab billing.
4. Safe macros and inline alternatives.
5. Header guards, multiple source files and DEBUG.
6. Formatted I/O and input validation.
7. Type conversion and precision surprises.
8. Compilation stages.
9. Integrated billing and five-bill test.
10. Scale and aggregate type comparison.
11. Final design recommendation.
12. Smart-meter redesign with runtime tariffs and peak-period input.

## Important submission checklist
- [ ] Confirm source code against the original assignment, especially the requirement to copy given starter code and replace only TODOs.
- [ ] Run every task on your own machine and save genuine screenshots in each Task folder.
- [ ] Replace the compiler version with the output of `gcc --version`.
- [ ] Complete the test tables with expected and actual results from your own runs.
- [ ] Add one meaningful Git commit per task over time.
- [ ] Share the repository with faculty and paste the working repository URL in the report cover page.
- [ ] Confirm your faculty accepts the chosen repository visibility and collaborator permissions.

**Academic integrity note:** Understand every program and be ready to explain it during the viva. Logs are sample execution evidence from this environment, not screenshots.
