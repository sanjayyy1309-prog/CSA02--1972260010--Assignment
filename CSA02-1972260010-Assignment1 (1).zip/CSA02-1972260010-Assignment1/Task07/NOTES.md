# Task07

Demonstrates integer division, binary floating-point approximation, truncating casts and evaluation order.
