#include <stdio.h>
#define RATE_PAISE 225
int main(void) {
    int units = 150;
    long energy = (long)(units > 100 ? units - 100 : 0) * RATE_PAISE;
    printf("Energy charge: %ld paise\n", energy);
    return 0;
}
