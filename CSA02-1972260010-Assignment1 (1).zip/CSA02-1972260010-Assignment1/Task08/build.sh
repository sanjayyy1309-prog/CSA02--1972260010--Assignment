#!/bin/sh
set -eu
gcc -std=c11 -Wall -Wextra -pedantic -E main.c -o main.i
gcc -std=c11 -Wall -Wextra -pedantic -S main.c -o main.s
gcc -std=c11 -Wall -Wextra -pedantic -c main.c -o main.o
gcc main.o -o main
./main
