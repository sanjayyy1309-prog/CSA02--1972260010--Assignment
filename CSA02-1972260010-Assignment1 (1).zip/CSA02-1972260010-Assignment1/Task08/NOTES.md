# Task08

Use gcc -E, -S, -c and linking to inspect the preprocessor, assembly, object and executable stages.
