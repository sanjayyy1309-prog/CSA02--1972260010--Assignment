# C Programming – Assignment 1 (CO1)
## Design, Implement and Validate a Reliable Billing Program for a Rural Electricity Co-operative

**Student:** Sanjay S  
**Register Number:** 1972260010  
**GitHub repository:** https://github.com/sanjayyy1309-prog/CSA02--1972260010--Assignment.git  
**Compiler:** GCC; fill in exact version using `gcc --version` on the machine used for final validation.  
**Submission date stated in assignment:** 26/10/2026

> Evidence note: The included `outputs/` files are compilation/run logs generated in the current environment. They are not screenshots from the student's own machine. Re-run the programs, capture screenshots, and record the actual compiler version before submission. The sample GitHub URL was provided by the student; this package does not claim to have pushed commits to it.

## Objective and scenario
Grama Jyothi Rural Electricity Co-operative bills about 4,000 households monthly. It records previous/current meter readings, calculates consumption, applies a fixed charge and slab-based energy rates. The design must prevent negative bills, rollover mistakes, inconsistent tariff revisions and monetary precision errors. Scale scenarios are 4,000, 60,000 and 800,000 households.

## Task 1 – Understand the problem and identify data
**Inputs:** household number (identifier), category (classification), previous reading, current reading. The readings are in the range 0–65535 for the stated 16-bit register.  
**Computed values:** units consumed, energy charge, fixed charge, total bill. The fixed charge and rates are configuration values.  
**Outputs:** household identifier/category, consumption and bill components, with rupees and paise formatted separately.  
**Assumptions:** readings are valid; at most one rollover occurs between readings; first 100 units are free for energy charge; 101–200 cost ₹2.25/unit; units above 200 cost ₹4.50/unit; fixed charge is ₹50.00.  
**Invariants:** charges are non-negative; total = fixed + energy charge; no floating-point rounding enters the paise total; invalid readings are rejected. Rollover consumption is `(unsigned short)(current - previous)` for a 16-bit register.

**Alternative: readings as strings.** A string such as `"01530"` preserves leading zeroes. Conversion and digit validation require O(d) time for d characters; storage is O(d) characters plus a terminator. An integer reading uses O(1) space for a fixed-width register and comparison/subtraction is O(1). Strings are useful for preserving input format but require parsing and validation.

## Task 2 – Choose data types
Use `unsigned short` for the stated 16-bit register (verify `USHRT_MAX` and `sizeof` on the actual system), `int` for small bounded units and menu/index values, `long` or `long long` for monetary paise totals, `char` for category, and `double` only for non-authoritative approximate analysis. Use `limits.h` and `float.h` to report local sizes/ranges; sizes are implementation-dependent except for minimum guarantees.

Money should be stored as integer paise: ₹162.50 becomes 16250 paise. Binary floating point cannot exactly represent many decimal fractions. Summing a fractional float thousands of times can accumulate error; integer paise makes each stored bill exact provided the chosen integer type does not overflow.

The rollover sample is 65400 → 120: `(65536 - 65400) + 120 = 136 + 120 = 256` units. Unsigned arithmetic wraps modulo 65536, so the result is not negative. The exact code output depends on the implementation's `sizeof(unsigned short)`; the assignment's expected output assumes 2 bytes.

**Alternative: double rupees.** Compute in `double`, round at the billing boundary (e.g., `round(amount * 100.0)` to paise), and define a consistent rounding policy. Addition is O(1) for either representation. A double typically uses more bytes than an integer on common systems; repeated floating calculations can introduce rounding error, while integer paise risks overflow if its range is insufficient.

## Task 3 – Define constants
The source centralises the fixed charge, slab boundaries and rates using uppercase `#define` names. Slab calculation:
- first 100 units: ₹0 energy charge;
- units 101–200: 100 × ₹2.25 maximum;
- each unit above 200: ₹4.50;
- fixed charge: ₹50.

Expected results from the assignment:
| Units | Expected bill |
|---:|---:|
| 0 | ₹50.00 |
| 100 | ₹50.00 |
| 150 | ₹162.50 |
| 200 | ₹275.00 |
| 350 | ₹950.00 |

Changing `RATE2_PAISE` from 225 to 230 updates all computations using that macro after recompilation. `#define` is textual and has no typed object or scope; `const` variables are typed and visible in debuggers but may occupy storage; `enum` suits integral named constants. Running time is normally unaffected after compilation. Runtime tariff files are better when authorised tariff changes must not require rebuilding the executable.

## Task 4 – Use macros safely
`SQUARE(x)` is written `((x) * (x))`, not `x*x`; the outer parentheses protect use in larger expressions and parameter parentheses protect arguments. `MAX(a,b)` can evaluate an argument twice, so avoid side effects such as `MAX(i++, j)`. Static inline functions provide type checking and evaluate each argument once, though inlining is compiler-dependent. Macro expansion is textual and may duplicate code at each use; a function can centralise machine code. Run `gcc -E main.c -o main.i` to inspect preprocessing.

Complexity: square/max operations are O(1) time and O(1) auxiliary space in either approach. Macro-generated code size may grow with k call sites; a shared function can reduce duplication, though the optimiser may inline it.

## Task 5 – Header files and conditional compilation
`billing.h` uses an include guard to prevent duplicate declarations. `main.c` calls `compute_bill()` from `billing.c`. Quoted includes search local/project paths; angle-bracket includes search system include paths. Compile with:
```sh
gcc -std=c11 -Wall -Wextra -pedantic main.c billing.c -o program
gcc -std=c11 -Wall -Wextra -pedantic -DDEBUG main.c billing.c -o program
```
`#ifdef DEBUG` removes diagnostic statements from a normal build. A runtime `if (debug)` leaves the branch and debug strings/code in the executable and incurs a branch test; conditional compilation can exclude the debug code entirely.

## Task 6 – Read and print correctly
Use `%d` for `int`, `%u` for `unsigned int`, `%ld` for `long`, `%lld` for `long long`, `%f` for `float` in `printf`, `%lf` for `double` in `scanf` (and `%f` for `float` in `scanf`), `%c` for `char`, and `%s` for a character array. A mismatched variadic format specifier causes undefined behaviour; do not demonstrate it in a production run. Always check `scanf`'s return count. `fgets()` followed by `strtol()`/`sscanf()` allows whole-line validation and recovery; processing a line of length L is O(L), with O(L) buffer space, compared with `scanf`'s direct conversion and less convenient recovery from malformed trailing input.

## Task 7 – Type conversion and precision
Examples:
- `7 / 2` gives `3`, because both operands are integers.
- `(double)7 / 2` gives `3.50`.
- `(int)3.9` gives `3`, because conversion truncates toward zero.
- `0.1 + 0.2` commonly prints an approximation such as `0.30000000000000004`.
- `5 / 2 * 2` gives `4` because integer division occurs before multiplication.

Prefer integer paise and define rounding when converting a fractional tariff calculation. If all calculations used float and rounded only once at the end, intermediate approximations could accumulate and a final rounding boundary could change the total. Both arithmetic operations are O(1) per bill; integer and floating storage sizes should be measured with `sizeof`.

## Task 8 – Trace compilation
Commands:
```sh
gcc -E main.c -o main.i   # preprocessed source
gcc -S main.c -o main.s   # assembly
gcc -c main.c -o main.o   # object file
gcc main.o -o program     # linked executable
gcc -std=c11 -Wall -Wextra -pedantic main.c -o program
```
Preprocessing expands macros and includes headers. Compile-time errors include invalid syntax or incompatible declarations; link-time errors include a missing definition for a referenced function; runtime errors include invalid input or arithmetic/design failures detected during execution. `-Wall -Wextra -pedantic` helps identify suspicious code, but not every bug. With multiple source files, only changed translation units generally need recompilation, then the program is relinked. Object-file disk space is O(total compiled code); one-file builds are simpler but can require recompiling the entire translation unit after changes.

## Task 9 – Implement and test billing
The integrated program validates reading ranges, calculates rollover-aware consumption, computes slab charges and totals five bills. Test input sample:
```text
0 100
100 200
200 350
65400 120
1200 1530
```
Analytical expected consumption values are 100, 100, 150, 256 and 330 units. The program should print each bill and a total. Test invalid text and out-of-range values separately; the current implementation rejects these. A reading decrease is interpreted as a rollover, so this implementation cannot distinguish a true rollover from a data-entry error without timestamp/rollover metadata.

**Alternative arrays and loop:** store slab limits/rates in arrays and loop over s slabs. Per bill becomes O(s) time and O(s) configuration space; fixed conditional logic is O(1) for a fixed number of slabs. Arrays are easier to extend without editing the calculation logic.

## Task 10 – Expectations versus execution and scale
For an illustrative ₹950.00 bill per household:
| Households | Total rupees | Total paise |
|---:|---:|---:|
| 4,000 | ₹3,800,000.00 | 380,000,000 |
| 60,000 | ₹57,000,000.00 | 5,700,000,000 |
| 800,000 | ₹760,000,000.00 | 76,000,000,000 |

These are scenario calculations, not actual average bills. On common 32-bit `int`, the paise totals exceed `INT_MAX` at 60,000 and 800,000 bills; `long long` has ample range for these totals. `long` is 32-bit on some systems and 64-bit on others, so inspect `LONG_MAX`. `double` can represent these aggregate whole-rupee values at this magnitude, but it does not guarantee exact decimal paise in all calculations. Integer overflow and floating precision loss are different failure modes. Addition is O(1), and storage per accumulator is O(1).

## Task 11 – Final recommendation
Use unsigned fixed-width or range-checked meter readings, a wider unsigned integer for consumption where appropriate, integer paise for individual bills, and `long long`/`int64_t` for totals. Centralise tariff configuration; use `#define` for compile-time constants and a validated configuration file for frequently changing tariff values. Validate input, reject impossible readings, log raw readings and test normal, boundary, rollover and invalid cases. For district-scale volume, per-bill arithmetic is O(1); processing N households is O(N). The principal limitations are rollover ambiguity, tariff changes during a billing period, and configuration validation.

**Alternative tariff configuration:** loading t tariff values costs O(t) startup time and O(t) storage, but avoids recompiling and redistributing for each authorised tariff revision. Configuration needs range checks, versioning and fallback behaviour.

## Task 12 – Day-4 smart-meter design challenge
### A. Impact analysis
The system changes from a monthly register to 15-minute watt-hour reports, time-of-day rates and runtime tariff changes. There are 35,040 intervals per house per year (365 × 24 × 4). At 800,000 houses this is 28,032,000,000 interval records/year before considering retries or metadata. A 16-bit meter register is not sufficient as the sole yearly accumulator. Use 64-bit totals and timestamped interval records. Tariffs should be loaded at runtime.

### B. Original design evaluation
The old slab model alone cannot express a peak surcharge from 18:00 to 22:00, timestamp classification, or runtime changes. A yearly sum of watt-hours can be very large: if an illustrative household used 10 kWh/day, annual consumption would be 3,650 kWh = 3,650,000 Wh; 800,000 such households would use 2,920,000,000 kWh = 2,920,000,000,000 Wh. These are illustrative assumptions, not measured usage. A 64-bit unsigned accumulator is appropriate with validated maximums.

### C. Adaptation/redesign
`Task12/main.c` accepts fixed charge, normal rate and peak rate at runtime, then a watt-hour interval and a peak flag. It demonstrates integer-based tariff selection and no recompilation for tariff edits. In a complete deployment, timestamps must determine peak status automatically, tariff data must be loaded from a validated configuration file, interval energy should be accumulated without losing fractional paise, and timezone/daylight rules must be explicit.

### D. Evidence-based defence
Redesign is recommended because the original model lacks interval timestamps and tariff configuration. 64-bit arithmetic supports yearly totals; runtime tariff input avoids rebuilds; peak classification adds an explicit rule. The prototype is a teaching implementation, not a production billing platform. It truncates each interval's fractional paise; production code should retain remainders or accumulate energy by tariff bucket before rounding once at the invoice boundary.

## UML-style flow
```text
[Start] -> [Read household and readings] -> [Validate input]
       -> [Calculate consumption incl. rollover] -> [Apply tariff slabs]
       -> [Add fixed charge] -> [Format paise as rupees.paise] -> [Print bill] -> [End]
```

## Pseudocode
```text
READ previous, current
IF either reading is outside 0..65535: report error and stop
units = (current - previous) modulo 65536
energy_paise = 0
IF units > 200: energy_paise += (units - 200) * 450
IF units > 100: energy_paise += (min(units, 200) - 100) * 225
total_paise = 5000 + energy_paise
PRINT units and total_paise as rupees and paise
```

## Final validation checklist
1. Run all 12 tasks on the target machine.
2. Save actual terminal screenshots in each task folder.
3. Fill actual GCC version and measured `sizeof`/limits.
4. Record expected and actual results, including invalid inputs.
5. Review each file and be prepared to explain it in a viva.
6. Commit each task progressively; don't fabricate historical commits.
