#include <stdio.h>
#include <float.h>
#include <limits.h>
int main(void) {
    const long bill_paise = 95000L; /* sample bill Rs 950.00 */
    const int counts[] = {4000, 60000, 800000};
    for (int i = 0; i < 3; ++i) {
        long long exact = (long long)bill_paise * counts[i];
        double approx = (double)bill_paise / 100.0 * counts[i];
        printf("%d bills: integer paise=%lld; double rupees=%.2f\n", counts[i], exact, approx);
    }
    printf("INT_MAX=%d LONG_MAX=%ld LLONG_MAX=%lld DBL_MANT_DIG=%d\n",
           INT_MAX, LONG_MAX, LLONG_MAX, DBL_MANT_DIG);
    return 0;
}
