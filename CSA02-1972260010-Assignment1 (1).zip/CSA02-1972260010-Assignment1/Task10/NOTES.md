# Task10

Compares exact integer-paise totals and double-rupee totals for scale scenarios. The per-house bill is a stated example, not a measured average.
