#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>

/* Runtime tariff configuration, all money values are integer paise per kWh.
   Interval readings are watt-hours; differences are converted to Wh and billed
   in integer milliwatt-hours-equivalent arithmetic only after tariff selection.
   For this simple example, bill in paise = Wh * paise_per_kWh / 1000. */
typedef struct {
    int64_t fixed_charge_paise;
    int64_t normal_rate_paise_per_kwh;
    int64_t peak_rate_paise_per_kwh;
} Tariff;

static int64_t interval_charge_paise(uint64_t watt_hours, int peak, const Tariff *t) {
    int64_t rate = peak ? t->peak_rate_paise_per_kwh : t->normal_rate_paise_per_kwh;
    /* Integer truncation is explicit. Production code should accumulate
       numerator remainders across intervals or use finer fixed-point units. */
    return (int64_t)(watt_hours * (uint64_t)rate / 1000U);
}
int main(void) {
    Tariff tariff;
    uint64_t wh;
    int peak;
    printf("Enter fixed charge (paise), normal rate (paise/kWh), peak rate (paise/kWh): ");
    if (scanf("%" SCNd64 " %" SCNd64 " %" SCNd64,
              &tariff.fixed_charge_paise, &tariff.normal_rate_paise_per_kwh,
              &tariff.peak_rate_paise_per_kwh) != 3) {
        fprintf(stderr, "Invalid tariff input.\n"); return 1;
    }
    if (tariff.fixed_charge_paise < 0 || tariff.normal_rate_paise_per_kwh < 0 ||
        tariff.peak_rate_paise_per_kwh < 0) {
        fprintf(stderr, "Tariffs cannot be negative.\n"); return 1;
    }
    printf("Enter interval consumption in Wh and peak flag (0=normal, 1=18:00-22:00): ");
    if (scanf("%" SCNu64 " %d", &wh, &peak) != 2 || (peak != 0 && peak != 1)) {
        fprintf(stderr, "Invalid interval input.\n"); return 1;
    }
    int64_t energy = interval_charge_paise(wh, peak, &tariff);
    int64_t total = tariff.fixed_charge_paise + energy;
    printf("Energy charge: %" PRId64 " paise\nTotal: Rs %" PRId64 ".%02" PRId64 "\n",
           energy, total / 100, total % 100);
    return 0;
}
