# Task12

Redesign uses 64-bit integer types, runtime-entered tariffs, watt-hour intervals and an explicit peak-period flag. This single-interval prototype illustrates the design; a production system must aggregate 35,040 timestamped intervals per house, classify time zones/peak intervals, and preserve fractional paise across intervals.
