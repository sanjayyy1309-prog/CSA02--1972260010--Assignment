#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int previous, current;
    printf("Enter previous and current meter readings (0..65535): ");
    if (scanf("%d %d", &previous, &current) != 2) {
        fprintf(stderr, "Invalid input: enter two integers.\n");
        return 1;
    }
    if (previous < 0 || previous > 65535 || current < 0 || current > 65535) {
        fprintf(stderr, "Readings must be in the range 0..65535.\n");
        return 1;
    }
    unsigned int units = (unsigned short)(current - previous);
    long bill = 5000L;
    if (units > 200) bill += (long)(units - 200) * 450L + 100L * 225L;
    else if (units > 100) bill += (long)(units - 100) * 225L;
    printf("Units: %u\nBill: Rs %ld.%02ld\n", units, bill / 100, bill % 100);
    return 0;
}
