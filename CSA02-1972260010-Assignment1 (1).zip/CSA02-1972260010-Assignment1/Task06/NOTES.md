# Task06

Checks scanf's return count and reading ranges. For production, validate rollover policy explicitly and use fgets/strtol for stronger line-level error recovery.
