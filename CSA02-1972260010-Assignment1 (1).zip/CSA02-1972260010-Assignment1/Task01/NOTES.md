# Task01

Identifies the input, computed and output data. The example is a simple data inventory demonstration; Task 9 implements validation and billing.
