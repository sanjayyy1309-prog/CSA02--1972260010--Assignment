# Test cases

Expected results below are analytical predictions unless marked as compiler-executed in `outputs/`.

- Normal reading increase: previous 1200, current 1530 -> 330 units.
- Rollover example: previous 65400, current 120 -> 256 units.
- Billing slab checks: 0, 100, 150, 200, 350 units.
- Invalid text/range cases should be rejected where input validation is implemented.
