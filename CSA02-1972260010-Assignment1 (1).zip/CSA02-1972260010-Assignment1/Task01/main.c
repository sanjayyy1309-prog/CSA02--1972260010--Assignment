#include <stdio.h>
#include <limits.h>

/* Inputs are 16-bit meter readings, household ID and category.
   The billing rules and rates are described in later tasks. */
typedef unsigned short meter_t;

int main(void) {
    meter_t previous = 1200, current = 1530;
    unsigned int units = (unsigned short)(current - previous);
    unsigned int household_id = 101;
    char category = 'D';
    long fixed_charge_paise = 5000L;
    printf("Household: %u\nCategory: %c\nPrevious: %u\nCurrent: %u\nUnits: %u\nFixed charge: %ld paise\n",
           household_id, category, (unsigned)previous, (unsigned)current, units, fixed_charge_paise);
    return 0;
}
